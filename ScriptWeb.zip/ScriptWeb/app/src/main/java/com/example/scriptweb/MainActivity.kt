package com.example.scriptweb

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {
    private val START_URL = "https://pokesurvivor.com/"
    // Chặn đoạn kiểm tra cập nhật dành cho bản Chrome extension (script tự bỏ qua nếu có GM_info)
    private val PRELUDE = "window.GM_info = window.GM_info || {};\n"

    private lateinit var web: WebView
    private lateinit var store: ScriptStore
    private val handlers = mutableListOf<ScriptHandler>()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val code = contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        if (code.isBlank()) { toast("File rỗng"); return@registerForActivityResult }
        store.add(code); applyScripts(); web.reload(); toast("Đã thêm script")
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // không tắt màn hình khi dùng app
        store = ScriptStore(this).also { it.seedDefault() }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        val root = FrameLayout(this)
        root.addView(web, ViewGroup.LayoutParams(-1, -1))

        // Nút của app (nằm ngoài trang web), kéo thả được, bấm để mở bảng tiện ích
        val size = dp(46)
        val fab = TextView(this).apply {
            text = "⚙"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xAA222222.toInt()) }
        }
        root.addView(fab, FrameLayout.LayoutParams(size, size, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(12), dp(80))
        })
        var dx = 0f; var dy = 0f; var moved = false
        fab.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = v.x - e.rawX; dy = v.y - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val nx = e.rawX + dx; val ny = e.rawY + dy
                    if (Math.abs(nx - v.x) + Math.abs(ny - v.y) > 6) moved = true
                    v.x = nx.coerceIn(0f, (root.width - v.width).toFloat())
                    v.y = ny.coerceIn(0f, (root.height - v.height).toFloat())
                }
                MotionEvent.ACTION_UP -> if (!moved) showPanel()
            }
            true
        }
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })

        applyScripts()
        web.loadUrl(START_URL)
    }

    /** Gỡ hết script cũ rồi đăng ký lại các script đang BẬT, chạy ở document-start. */
    private fun applyScripts() {
        handlers.forEach { it.remove() }; handlers.clear()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            toast("WebView quá cũ, hãy cập nhật Android System WebView"); return
        }
        store.list().filter { it.enabled }.forEach { s ->
            handlers += WebViewCompat.addDocumentStartJavaScript(web, PRELUDE + s.code, s.originRules())
        }
    }

    private fun showPanel() {
        var changed = false
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val scripts = store.list()
        if (scripts.isEmpty()) box.addView(TextView(this).apply { text = "Chưa có tiện ích nào"; setPadding(0, dp(16), 0, dp(16)) })
        val confirmDelete = { s: UserScript ->
            AlertDialog.Builder(this@MainActivity).setMessage("Xóa \"${s.name}\"?")
                .setPositiveButton("Xóa") { _, _ -> store.delete(s.id); changed = true; dialog.dismiss() }
                .setNegativeButton("Hủy", null).show()
        }
        scripts.forEach { s ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(SwitchCompat(this).apply {
                text = s.name; textSize = 16f; isChecked = s.enabled
                setPadding(0, dp(14), dp(8), dp(14))
                setOnCheckedChangeListener { _, on -> store.setEnabled(s.id, on); changed = true }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = "Xóa"; textSize = 14f; setTextColor(0xFFE53935.toInt())
                setPadding(dp(14), dp(12), dp(4), dp(12))
                setOnClickListener { confirmDelete(s) }
            })
            box.addView(row)
        }
        dialog = AlertDialog.Builder(this)
            .setTitle("Tiện ích")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Đóng", null)
            .setNeutralButton("Thêm script") { _, _ -> picker.launch(arrayOf("*/*")) }
            .setOnDismissListener { if (changed) { applyScripts(); web.reload() } }
            .create()
        dialog.show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
